package kgym;

public class Usuario {

    private String nombre;
    private String clave;
    private String avatar;
    private int anioNacimiento;
    private double peso;
    private double estatura;

    public Usuario(String nombre, String clave, String avatar, int anioNacimiento, double peso, double estatura) {
        this.nombre = nombre;
        this.clave = clave;
        this.avatar = avatar;
        this.anioNacimiento = anioNacimiento;
        this.peso = peso;
        this.estatura = estatura;
    }

    public double getIMC() {
        return peso / (estatura * estatura);
    }

    public String getNombre() {
        return nombre;
    }

    public String getClave() {
        return clave;
    }

    public String getAvatar() {
        return avatar;
    }

    public int getAnioNacimiento() {
        return anioNacimiento;
    }

    public double getPeso() {
        return peso;
    }

    public double getEstatura() {
        return estatura;
    }

    @Override
    public String toString() {
        return nombre + ";" + clave + ";" + avatar + ";" + anioNacimiento + ";" + peso + ";" + estatura;
    }

}
