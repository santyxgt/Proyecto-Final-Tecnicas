package kgym;

import java.io.Serializable;

public class Usuario implements Serializable {
    private String nombre;
    private String clave;
    private String avatar; // nuevo campo
    
    public Usuario(String nombre, String clave, String avatar) {
        this.nombre = nombre;
        this.clave = clave;
        this.avatar = avatar;
    }

    public String getNombre() {
        return nombre;
    }

    public String getClave() {
        return clave;
    }

    public String getAvatar() {
        return avatar;
    }

    @Override
    public String toString() {
        return nombre + "," + clave + "," + avatar;
    }
}
