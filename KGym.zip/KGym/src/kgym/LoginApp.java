package kgym;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginApp extends JFrame implements ActionListener {

    private JTextField campoUsuario;
    private JPasswordField campoClave;
    private JButton botonLogin, botonRegistro, botonSalir;
    private JLabel mensaje;

    public LoginApp() {
        setTitle("Login con Registro");
        setSize(350, 250);
        setLayout(new GridLayout(8, 1)); // Aumentamos el número de filas para ajustar mejor los botones
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        campoUsuario = new JTextField();
        campoClave = new JPasswordField();
        botonLogin = new JButton("Ingresar");
        botonRegistro = new JButton("Registrar");
        botonSalir = new JButton("Salir");
        mensaje = new JLabel("", SwingConstants.CENTER);

        // Establecer tamaño mínimo para los botones
        botonLogin.setPreferredSize(new Dimension(200, 40));
        botonRegistro.setPreferredSize(new Dimension(200, 40));
        botonSalir.setPreferredSize(new Dimension(200, 40));

        add(new JLabel("Usuario:"));
        add(campoUsuario);
        add(new JLabel("Contraseña:"));
        add(campoClave);
        add(botonLogin);
        add(botonRegistro);
        add(botonSalir); 
        add(mensaje);

        botonLogin.addActionListener(this);
        botonRegistro.addActionListener(this);
        botonSalir.addActionListener(this); 

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nombreUsuario = campoUsuario.getText().trim();
        String clave = new String(campoClave.getPassword()).trim();

        if (e.getSource() == botonSalir) {
            System.exit(0); // Cerrar la aplicación
        }

        try {
            if (e.getSource() == botonLogin) {
                Usuario usuario = GestorUsuarios.obtenerUsuario(nombreUsuario, clave);
                if (usuario != null) {
                    dispose(); // Cerrar la ventana de login
                    new VentanaPerfil(usuario); // Abrir ventana de perfil con avatar
                } else {
                    mensaje.setForeground(Color.RED);
                    mensaje.setText("Credenciales inválidas.");
                }

            } else if (e.getSource() == botonRegistro) {
                // Crear un panel con GridLayout para mostrar las imágenes en 2x2
                JPanel panelImagenes = new JPanel(new GridLayout(2, 2, 10, 10)); // 2x2, con espacio entre imágenes

                // Opciones de imágenes 
                String[] opciones = {"avatar1.png", "avatar2.png", "avatar3.png", "avatar4.png"};
                JButton[] botonesImagen = new JButton[opciones.length];

                // Crear los botones con las imágenes
                for (int i = 0; i < opciones.length; i++) {
                    ImageIcon img = new ImageIcon("imagenes/" + opciones[i]);
                    Image imgEscalada = img.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH); // Ajustar tamaño
                    botonesImagen[i] = new JButton(new ImageIcon(imgEscalada));

                    // Agregar un listener a cada botón
                    int index = i;
                    botonesImagen[i].addActionListener(event -> {
                        try {
                            String avatarElegido = opciones[index];
                            // Guardar el usuario con el avatar elegido
                            GestorUsuarios.guardarUsuario(new Usuario(nombreUsuario, clave, avatarElegido));
                            
                            // Cerrar la ventana de registro
                            dispose();

                            // Abrir la ventana de perfil con el nuevo avatar
                            Usuario usuarioRegistrado = GestorUsuarios.obtenerUsuario(nombreUsuario, clave);
                            if (usuarioRegistrado != null) {
                                new VentanaPerfil(usuarioRegistrado);
                            }

                            mensaje.setForeground(Color.BLUE);
                            mensaje.setText("Usuario registrado con avatar.");

                        } catch (IOException ex) {
                            Logger.getLogger(LoginApp.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });

                    panelImagenes.add(botonesImagen[i]); // Agregar botón al panel
                }

                // Mostrar el panel de selección de avatar en un JOptionPane
                JOptionPane.showMessageDialog(this, panelImagenes, "Selecciona tu avatar", JOptionPane.QUESTION_MESSAGE);

            }
        } catch (IOException ex) {
            mensaje.setForeground(Color.RED);
            mensaje.setText("Error: " + ex.getMessage());
        }
    }
}
