package kgym;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class LoginApp extends JFrame implements ActionListener {

    private JTextField campoUsuario;
    private JPasswordField campoClave;
    private JButton botonLogin, botonRegistro, botonSalir;
    private JLabel mensaje;

    public LoginApp() {
        setTitle("Login con Registro");
        setSize(350, 250);
        setLayout(new GridLayout(8, 1));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        campoUsuario = new JTextField();
        campoClave = new JPasswordField();
        botonLogin = new JButton("Ingresar");
        botonRegistro = new JButton("Registrar");
        botonSalir = new JButton("Salir");
        mensaje = new JLabel("", SwingConstants.CENTER);

        botonLogin.setPreferredSize(new Dimension(200, 40));
        botonRegistro.setPreferredSize(new Dimension(200, 40));
        botonSalir.setPreferredSize(new Dimension(200, 40));

        add(new JLabel("Usuario:"));
        add(campoUsuario);
        add(new JLabel("Contraseña:"));
        add(campoClave);
        add(botonLogin);
        add(botonRegistro);
        add(botonSalir);
        add(mensaje);

        botonLogin.addActionListener(this);
        botonRegistro.addActionListener(this);
        botonSalir.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nombreUsuario = campoUsuario.getText().trim();
        String clave = new String(campoClave.getPassword()).trim();

        if (e.getSource() == botonSalir) {
            System.exit(0);
        }

        try {
            if (e.getSource() == botonLogin) {
                Usuario usuario = GestorUsuarios.obtenerUsuario(nombreUsuario, clave);
                if (usuario != null) {
                    dispose();
                    new VentanaPerfil(usuario);
                } else {
                    mensaje.setForeground(Color.RED);
                    mensaje.setText("Credenciales inválidas.");
                }
            } else if (e.getSource() == botonRegistro) {
                JPanel panelImagenes = new JPanel(new GridLayout(2, 2, 10, 10));
                String[] opciones = {"avatar1.png", "avatar2.png", "avatar3.png", "avatar4.png"};
                JButton[] botonesImagen = new JButton[opciones.length];
                JDialog dialogo = new JDialog(this, "Selecciona un avatar", true);

                for (int i = 0; i < opciones.length; i++) {
                    ImageIcon img = new ImageIcon("imagenes/" + opciones[i]);
                    Image imgEscalada = img.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    botonesImagen[i] = new JButton(new ImageIcon(imgEscalada));

                    int index = i;
                    botonesImagen[i].addActionListener(ae -> {
                        dialogo.dispose();
                        String avatarElegido = opciones[index];

                        JTextField campoAnio = new JTextField();
                        JTextField campoPeso = new JTextField();
                        JTextField campoEstatura = new JTextField();

                        JPanel panelDatos = new JPanel(new GridLayout(3, 2));
                        panelDatos.add(new JLabel("Año de nacimiento:"));
                        panelDatos.add(campoAnio);
                        panelDatos.add(new JLabel("Peso (kg):"));
                        panelDatos.add(campoPeso);
                        panelDatos.add(new JLabel("Estatura (m):"));
                        panelDatos.add(campoEstatura);

                        int resultado = JOptionPane.showConfirmDialog(this, panelDatos, "Completa tu perfil", JOptionPane.OK_CANCEL_OPTION);
                        if (resultado == JOptionPane.OK_OPTION) {
                            try {
                                int anio = Integer.parseInt(campoAnio.getText().trim());
                                double peso = Double.parseDouble(campoPeso.getText().trim());
                                double estatura = Double.parseDouble(campoEstatura.getText().trim());

                                Usuario nuevoUsuario = new Usuario(nombreUsuario, clave, avatarElegido, anio, peso, estatura);
                                GestorUsuarios.guardarUsuario(nuevoUsuario);

                                dispose();
                                new VentanaPerfil(nuevoUsuario);
                            } catch (IOException | NumberFormatException ex) {
                                mensaje.setForeground(Color.RED);
                                mensaje.setText("Error: " + ex.getMessage());
                            }
                        }
                    });

                    panelImagenes.add(botonesImagen[i]);
                }

                dialogo.add(panelImagenes);
                dialogo.pack();
                dialogo.setLocationRelativeTo(this);
                dialogo.setVisible(true);
            }
        } catch (Exception ex) {
            mensaje.setForeground(Color.RED);
            mensaje.setText("Error general: " + ex.getMessage());
        }
    }
}
