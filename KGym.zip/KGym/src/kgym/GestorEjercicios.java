package kgym;

import java.util.ArrayList;
import java.util.List;

public class GestorEjercicios {

    private static final List<Ejercicio> ejercicios = new ArrayList<>();

    static {
        // Pecho
        ejercicios.add(new Ejercicio("Press de banca", "Pecho", 4, 6));
        ejercicios.add(new Ejercicio("Press de banca", "Pecho", 4, 12));
        ejercicios.add(new Ejercicio("Fondos en paralelas", "Pecho", 3, 15));
        ejercicios.add(new Ejercicio("Aperturas con mancuernas", "Pecho", 3, 12)); // Nuevo ejercicio
        ejercicios.add(new Ejercicio("Cruces en polea", "Pecho", 3, 12)); // Nuevo ejercicio

        // Espalda
        ejercicios.add(new Ejercicio("Dominadas", "Espalda", 4, 5));
        ejercicios.add(new Ejercicio("Remo con barra", "Espalda", 4, 10));
        ejercicios.add(new Ejercicio("Remo con mancuerna", "Espalda", 3, 15));
        ejercicios.add(new Ejercicio("Jalón al pecho", "Espalda", 4, 12)); // Nuevo ejercicio
        ejercicios.add(new Ejercicio("Remo en polea baja", "Espalda", 3, 12)); // Nuevo ejercicio

        // Piernas
        ejercicios.add(new Ejercicio("Sentadillas", "Piernas", 5, 5));
        ejercicios.add(new Ejercicio("Prensa de piernas", "Piernas", 4, 12));
        ejercicios.add(new Ejercicio("Extensiones de piernas", "Piernas", 3, 15));
        ejercicios.add(new Ejercicio("Curl de piernas", "Piernas", 3, 15)); // Nuevo ejercicio
        ejercicios.add(new Ejercicio("Peso muerto rumano", "Piernas", 4, 8)); // Nuevo ejercicio
        ejercicios.add(new Ejercicio("Zancadas", "Piernas", 3, 12)); // Nuevo

        // Bíceps
        ejercicios.add(new Ejercicio("Curl con barra", "Bíceps", 4, 12));
        ejercicios.add(new Ejercicio("Curl martillo", "Bíceps", 3, 15));
        ejercicios.add(new Ejercicio("Curl concentrado", "Bíceps", 3, 12)); // Nuevo ejercicio
        ejercicios.add(new Ejercicio("Curl en polea baja", "Bíceps", 3, 12)); // Nuevo

        // Tríceps
        ejercicios.add(new Ejercicio("Press francés", "Tríceps", 4, 12));
        ejercicios.add(new Ejercicio("Fondos para tríceps", "Tríceps", 4, 6));
        ejercicios.add(new Ejercicio("Extensiones con cuerda", "Tríceps", 3, 15)); // Nuevo ejercicio
        ejercicios.add(new Ejercicio("Press banca cerrado", "Tríceps", 4, 8)); // Nuevo

        // Hombro
        ejercicios.add(new Ejercicio("Press militar", "Hombro", 4, 8)); // Nuevo
        ejercicios.add(new Ejercicio("Elevaciones laterales", "Hombro", 3, 12)); // Nuevo
        ejercicios.add(new Ejercicio("Elevaciones frontales", "Hombro", 3, 12)); // Nuevo
        ejercicios.add(new Ejercicio("Remo al mentón", "Hombro", 3, 10)); // Nuevo
        ejercicios.add(new Ejercicio("Pájaros", "Hombro", 3, 15)); // Nuevo
    }

    public static List<Ejercicio> obtenerEjercicios(String objetivo, String intensidad,
            List<String> musculosSeleccionados) {
        List<Ejercicio> resultados = new ArrayList<>();

        for (Ejercicio e : ejercicios) {
            boolean objetivoCoincide = e.getObjetivo().equalsIgnoreCase(objetivo);
            boolean intensidadCoincide = e.getIntensidad().equalsIgnoreCase(intensidad);
            boolean musculoCoincide = musculosSeleccionados.contains(e.getMusculo());

            if (objetivoCoincide && intensidadCoincide && musculoCoincide) {
                resultados.add(e);
            }
        }

        return resultados;
    }
}
