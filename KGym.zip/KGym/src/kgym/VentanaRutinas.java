package kgym;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class VentanaRutinas extends JFrame {

    public VentanaRutinas(Usuario usuario) {
        setTitle("Rutinas guardadas");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTextArea areaRutinas = new JTextArea();
        areaRutinas.setEditable(false);
        areaRutinas.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(areaRutinas);
        add(scroll, BorderLayout.CENTER);

        // Leer rutinas del archivo y mostrarlas
        try (BufferedReader reader = new BufferedReader(new FileReader("rutinas.txt"))) {
            StringBuilder sb = new StringBuilder();
            String linea;
            boolean mostrar = false;

            while ((linea = reader.readLine()) != null) {
                if (linea.contains("Rutina para: " + usuario.getNombre())) {
                    mostrar = true;
                }

                if (mostrar) {
                    sb.append(linea).append("\n");
                    if (linea.contains("-------------------------")) {
                        mostrar = false;
                    }
                }
            }

            if (sb.length() == 0) {
                areaRutinas.setText("No se encontraron rutinas para el usuario.");
            } else {
                areaRutinas.setText(sb.toString());
            }

        } catch (IOException e) {
            areaRutinas.setText("No se pudo leer el archivo de rutinas.");
        }

        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
}
