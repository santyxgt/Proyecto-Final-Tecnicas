package kgym;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.List;

public class VentanaRutinas extends JFrame {

    public VentanaRutinas(Usuario usuario) {
        setTitle("Rutinas guardadas");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTextArea areaRutinas = new JTextArea();
        areaRutinas.setEditable(false);
        areaRutinas.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(areaRutinas);
        add(scroll, BorderLayout.CENTER);

        // Leer rutinas del archivo y mostrarlas
        try {
            List<Rutina> rutinas = GestorRutinas.cargarRutinas();
            StringBuilder sb = new StringBuilder();
            for (Rutina rutina : rutinas) {
                if (rutina.getNombreUsuario().equals(usuario.getNombre())) {
                    sb.append("Objetivo: ").append(rutina.getObjetivo()).append("\n");
                    sb.append("Intensidad: ").append(rutina.getIntensidad()).append("\n");
                    sb.append("Días: ").append(String.join(", ", rutina.getDiasDeLaSemana())).append("\n"); // Mostrar días
                    sb.append("Ejercicios:\n");
                    for (Ejercicio ejercicio : rutina.getEjercicios()) {
                        sb.append(" - ").append(ejercicio.getNombre())
                          .append(" (").append(ejercicio.getMusculo())
                          .append("): ").append(ejercicio.getSeries())
                          .append(" series x ").append(ejercicio.getRepeticiones()).append(" repeticiones\n");
                    }
                    sb.append("\n-------------------------\n");
                }
            }
            if (sb.length() == 0) {
                areaRutinas.setText("No se encontraron rutinas para el usuario.");
            } else {
                areaRutinas.setText(sb.toString());
            }
        } catch (IOException e) {
            areaRutinas.setText("No se pudo leer el archivo de rutinas.");
            e.printStackTrace();
        }

        setVisible(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
}