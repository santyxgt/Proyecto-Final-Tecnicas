package kgym;

import java.util.ArrayList;
import java.util.List;

public class GeneradorRutina {

    public static List<Ejercicio> generar(String objetivo, String intensidad) {
        List<Ejercicio> ejercicios = new ArrayList<>();

        if (objetivo == null || intensidad == null) {
            // Evitar null pointer
            return ejercicios;
        }

        objetivo = objetivo.toLowerCase();
        intensidad = intensidad.toLowerCase();

        int series;
        int repeticiones;

        switch (objetivo) {
            case "hipertrofia":
                switch (intensidad) {
                    case "baja": series = 3; repeticiones = 10; break;
                    case "media": series = 4; repeticiones = 10; break;
                    case "alta": series = 5; repeticiones = 12; break;
                    default: series = 3; repeticiones = 10; break;
                }
                ejercicios.add(new Ejercicio("Press de banca", "Pecho", series, repeticiones));
                ejercicios.add(new Ejercicio("Sentadillas", "Piernas", series, repeticiones));
                ejercicios.add(new Ejercicio("Remo con barra", "Espalda", series, repeticiones));
                break;

            case "resistencia":
                switch (intensidad) {
                    case "baja": series = 2; repeticiones = 20; break;
                    case "media": series = 3; repeticiones = 25; break;
                    case "alta": series = 4; repeticiones = 30; break;
                    default: series = 2; repeticiones = 20; break;
                }
                ejercicios.add(new Ejercicio("Burpees", "Cuerpo completo", series, repeticiones));
                ejercicios.add(new Ejercicio("Zancadas", "Piernas", series, repeticiones));
                ejercicios.add(new Ejercicio("Flexiones", "Pecho", series, repeticiones));
                break;

            case "pérdida de grasa":
                switch (intensidad) {
                    case "baja": series = 3; repeticiones = 15; break;
                    case "media": series = 4; repeticiones = 20; break;
                    case "alta": series = 5; repeticiones = 25; break;
                    default: series = 3; repeticiones = 15; break;
                }
                ejercicios.add(new Ejercicio("Jumping jacks", "Cardio", series, repeticiones));
                ejercicios.add(new Ejercicio("Mountain climbers", "Cardio", series, repeticiones));
                ejercicios.add(new Ejercicio("Cuerda", "Cardio", series, repeticiones));
                break;

            default:
                ejercicios.add(new Ejercicio("Caminata ligera", "Cardio", 2, 15));
        }

        return ejercicios;
    }
}
