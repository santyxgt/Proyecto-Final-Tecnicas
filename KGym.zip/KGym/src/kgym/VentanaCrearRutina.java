package kgym;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class VentanaCrearRutina extends JFrame {

    private JComboBox<String> comboObjetivo;
    private JComboBox<String> comboIntensidad;
    private JTextArea areaRutina;
    private JCheckBox[] checkDias = new JCheckBox[7]; // Para los días de la semana

    public VentanaCrearRutina(Usuario usuario) {

        setTitle("Crear Rutina");
        setSize(500, 500); 
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel de selección
        JPanel panelSeleccion = new JPanel(new GridLayout(5, 2, 10, 10)); 

        comboObjetivo = new JComboBox<>(new String[]{"Hipertrofia", "Resistencia", "Pérdida de grasa"});
        comboIntensidad = new JComboBox<>(new String[]{"Baja", "Media", "Alta"});

        panelSeleccion.add(new JLabel("Objetivo:"));
        panelSeleccion.add(comboObjetivo);
        panelSeleccion.add(new JLabel("Intensidad:"));
        panelSeleccion.add(comboIntensidad);

        // Checkboxes de los días de la semana
        String[] nombresDias = {"Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"};
        for (int i = 0; i < 7; i++) {
            checkDias[i] = new JCheckBox(nombresDias[i]);
            panelSeleccion.add(checkDias[i]);
        }

        JButton btnGenerar = new JButton("Generar Rutina");
        panelSeleccion.add(new JLabel()); 
        panelSeleccion.add(btnGenerar);

        add(panelSeleccion, BorderLayout.NORTH);

        // Área para mostrar la rutina generada
        areaRutina = new JTextArea();
        areaRutina.setEditable(false);
        JScrollPane scrollRutina = new JScrollPane(areaRutina);
        add(scrollRutina, BorderLayout.CENTER);

        // Botón para guardar la rutina
        JButton btnGuardar = new JButton("Guardar Rutina");
        add(btnGuardar, BorderLayout.SOUTH);

        // Evento para generar la rutina
        btnGenerar.addActionListener(e -> {
            String objetivo = (String) comboObjetivo.getSelectedItem();
            String intensidad = (String) comboIntensidad.getSelectedItem();
            List<Ejercicio> ejercicios = GeneradorRutina.generar(objetivo, intensidad);

            StringBuilder sb = new StringBuilder();
            sb.append("Rutina para: ").append(usuario.getNombre()).append("\n");
            sb.append("Objetivo: ").append(objetivo).append("\n");
            sb.append("Intensidad: ").append(intensidad).append("\n\n");

            for (Ejercicio ejercicio : ejercicios) {
                sb.append("- ").append(ejercicio.getNombre())
                  .append(" (").append(ejercicio.getMusculo()).append("): ")
                  .append(ejercicio.getSeries()).append("x").append(ejercicio.getRepeticiones()).append("\n");
            }

            areaRutina.setText(sb.toString());
        });

        // Evento para guardar la rutina
        btnGuardar.addActionListener(e -> {
            if (areaRutina.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Primero genera una rutina.");
                return;
            }

            try {
                // Obtener los días seleccionados
                List<String> diasSeleccionados = new ArrayList<>();
                for (int i = 0; i < 7; i++) {
                    if (checkDias[i].isSelected()) {
                        diasSeleccionados.add(nombresDias[i]);
                    }
                }

                if (diasSeleccionados.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Selecciona al menos un día para la rutina.");
                    return;
                }

                String objetivo = (String) comboObjetivo.getSelectedItem();
                String intensidad = (String) comboIntensidad.getSelectedItem();
                List<Ejercicio> ejercicios = GeneradorRutina.generar(objetivo, intensidad);

                Rutina nuevaRutina = new Rutina(usuario.getNombre(), objetivo, intensidad, diasSeleccionados, ejercicios); // MODIFICADO
                GestorRutinas.guardarRutina(nuevaRutina);

                JOptionPane.showMessageDialog(this, "Rutina guardada con éxito.");
                dispose(); 
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar la rutina.");
            }
        });

        setVisible(true);

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
}
  