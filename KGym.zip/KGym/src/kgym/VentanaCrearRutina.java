package kgym;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.List;

public class VentanaCrearRutina extends JFrame {

    private Usuario usuario;
    private JComboBox<String> comboObjetivo;
    private JComboBox<String> comboIntensidad;
    private JTextArea areaRutina;

    public VentanaCrearRutina(Usuario usuario) {
        this.usuario = usuario;

        setTitle("Crear Rutina");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Panel de selección
        JPanel panelSeleccion = new JPanel(new GridLayout(3, 2, 10, 10));

        comboObjetivo = new JComboBox<>(new String[]{"Hipertrofia", "Resistencia", "Pérdida de grasa"});
        comboIntensidad = new JComboBox<>(new String[]{"Baja", "Media", "Alta"});

        panelSeleccion.add(new JLabel("Objetivo:"));
        panelSeleccion.add(comboObjetivo);
        panelSeleccion.add(new JLabel("Intensidad:"));
        panelSeleccion.add(comboIntensidad);

        JButton btnGenerar = new JButton("Generar Rutina");
        panelSeleccion.add(new JLabel());
        panelSeleccion.add(btnGenerar);

        add(panelSeleccion, BorderLayout.NORTH);

        // Área para mostrar rutina
        areaRutina = new JTextArea();
        areaRutina.setEditable(false);
        areaRutina.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(areaRutina);
        add(scroll, BorderLayout.CENTER);

        // Botón para guardar
        JButton btnGuardar = new JButton("Guardar Rutina");
        add(btnGuardar, BorderLayout.SOUTH);

        // Evento para generar rutina
        btnGenerar.addActionListener(e -> {
            String objetivo = comboObjetivo.getSelectedItem().toString();
            String intensidad = comboIntensidad.getSelectedItem().toString();
            List<Ejercicio> ejercicios = GeneradorRutina.generar(objetivo, intensidad);

            StringBuilder sb = new StringBuilder();
            sb.append("Rutina para: ").append(usuario.getNombre()).append("\n");
            sb.append("Objetivo: ").append(objetivo).append("\n");
            sb.append("Intensidad: ").append(intensidad).append("\n\n");

            for (Ejercicio ejercicio : ejercicios) {
                sb.append("- ").append(ejercicio.getNombre())
                  .append(" (").append(ejercicio.getMusculo()).append("): ")
                  .append(ejercicio.getSeries()).append("x").append(ejercicio.getRepeticiones()).append("\n");
            }

            areaRutina.setText(sb.toString());
        });

        // Evento para guardar rutina
        btnGuardar.addActionListener(e -> {
            if (areaRutina.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Primero genera una rutina.");
                return;
            }

            try (FileWriter fw = new FileWriter("rutinas.txt", true)) {
                fw.write(areaRutina.getText());
                fw.write("\n-------------------------\n");
                JOptionPane.showMessageDialog(this, "Rutina guardada con éxito.");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error al guardar la rutina.");
            }
        });

        setVisible(true);

        // Cerrar correctamente
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
}
