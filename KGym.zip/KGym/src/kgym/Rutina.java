package kgym;

import java.util.List;

public class Rutina {
    private String nombreUsuario;
    private String objetivo;
    private String intensidad;
    private List<Ejercicio> ejercicios;

    public Rutina(String nombreUsuario, String objetivo, String intensidad, List<Ejercicio> ejercicios) {
        this.nombreUsuario = nombreUsuario;
        this.objetivo = objetivo;
        this.intensidad = intensidad;
        this.ejercicios = ejercicios;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public String getIntensidad() {
        return intensidad;
    }

    public List<Ejercicio> getEjercicios() {
        return ejercicios;
    }

    // Para guardar en texto plano, convertimos a String con un formato fácil de leer/escribir
    public String toArchivoString() {
        StringBuilder sb = new StringBuilder();
        // Línea con datos básicos
        sb.append(nombreUsuario).append(";").append(objetivo).append(";").append(intensidad).append("\n");
        // Luego cada ejercicio por línea
        for (Ejercicio e : ejercicios) {
            sb.append(e.getNombre()).append(",")
              .append(e.getMusculo()).append(",")
              .append(e.getSeries()).append(",")
              .append(e.getRepeticiones()).append("\n");
        }
        // Línea vacía para separar rutinas
        sb.append("\n");
        return sb.toString();
    }
}
