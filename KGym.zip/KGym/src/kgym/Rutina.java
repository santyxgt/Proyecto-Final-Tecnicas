package kgym;

import java.util.List;

public class Rutina {
    private String nombreUsuario;
    private String objetivo;
    private String intensidad;
    private List<String> diasDeLaSemana; 
    private List<Ejercicio> ejercicios;

    public Rutina(String nombreUsuario, String objetivo, String intensidad, List<String> diasDeLaSemana, List<Ejercicio> ejercicios) { 
        this.nombreUsuario = nombreUsuario;
        this.objetivo = objetivo;
        this.intensidad = intensidad;
        this.diasDeLaSemana = diasDeLaSemana; 
        this.ejercicios = ejercicios;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public String getIntensidad() {
        return intensidad;
    }

    public List<Ejercicio> getEjercicios() {
        return ejercicios;
    }

    public List<String> getDiasDeLaSemana() { // AÑADIDO
        return diasDeLaSemana;
    }

    public String toArchivoString() {
        StringBuilder sb = new StringBuilder();
        // Línea con datos básicos: usuario;objetivo;intensidad;dias
        sb.append(nombreUsuario).append(";").append(objetivo).append(";").append(intensidad).append(";").append(String.join(",", diasDeLaSemana)).append("\n"); // MODIFICADO
        // Luego cada ejercicio por línea
        for (Ejercicio e : ejercicios) {
            sb.append(e.getNombre()).append(",").append(e.getMusculo()).append(",").append(e.getSeries()).append(",").append(e.getRepeticiones()).append("\n");
        }
        sb.append("\n"); // Separador entre rutinas
        return sb.toString();
    }
}