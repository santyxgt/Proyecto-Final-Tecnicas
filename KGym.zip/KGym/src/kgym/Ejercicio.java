package kgym;

public class Ejercicio {
    private String nombre;
    private String musculo;
    private String objetivo; // Ejemplo: "Fuerza", "Resistencia", "Hipertrofia"
    private String intensidad; // Ejemplo: "Baja", "Media", "Alta"
    private int series;
    private int repeticiones;

    public Ejercicio(String nombre, String musculo, int series, int repeticiones) {
        this.nombre = nombre;
        this.musculo = musculo;
        this.objetivo = objetivo;
        this.intensidad = intensidad;
        this.series = series;
        this.repeticiones = repeticiones;
    }

    public String getNombre() {
        return nombre;
    }

    public String getMusculo() {
        return musculo;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public String getIntensidad() {
        return intensidad;
    }

    public int getSeries() {
        return series;
    }

    public int getRepeticiones() {
        return repeticiones;
    }

    @Override
    public String toString() {
        return nombre + " (" + musculo + ") - " + objetivo + ", " + intensidad + " | Series: " + series + ", Repeticiones: " + repeticiones;
    }
}
