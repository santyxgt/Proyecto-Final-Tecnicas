package kgym;

import java.io.*;
import java.util.*;

public class GestorRutinas {

    private static final String RUTINAS_TXT = "rutinas.txt";

    public static void guardarRutina(Rutina rutina) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTINAS_TXT, true))) {
            bw.write(rutina.toArchivoString());
        }
    }

    public static List<Rutina> cargarRutinas() throws IOException {
        List<Rutina> listaRutinas = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RUTINAS_TXT))) {
            String linea;
            String nombreUsuario = null, objetivo = null, intensidad = null;
            List<Ejercicio> ejercicios = null;

            while ((linea = br.readLine()) != null) {
                linea = linea.trim();
                if (linea.isEmpty()) {
                    // Fin de rutina, guardar si hay ejercicios
                    if (nombreUsuario != null && ejercicios != null) {
                        listaRutinas.add(new Rutina(nombreUsuario, objetivo, intensidad, ejercicios));
                    }
                    nombreUsuario = null; objetivo = null; intensidad = null; ejercicios = null;
                } else if (nombreUsuario == null) {
                    // Primera línea de rutina: usuario;objetivo;intensidad
                    String[] partes = linea.split(";");
                    if (partes.length == 3) {
                        nombreUsuario = partes[0];
                        objetivo = partes[1];
                        intensidad = partes[2];
                        ejercicios = new ArrayList<>();
                    }
                } else {
                    // Ejercicio: nombre,músculo,series,repeticiones
                    String[] partesEj = linea.split(",");
                    if (partesEj.length == 4) {
                        String nombreEj = partesEj[0];
                        String musculo = partesEj[1];
                        int series = Integer.parseInt(partesEj[2]);
                        int repeticiones = Integer.parseInt(partesEj[3]);
                        ejercicios.add(new Ejercicio(nombreEj, musculo, series, repeticiones));
                    }
                }
            }

            // Por si el archivo no termina con línea vacía
            if (nombreUsuario != null && ejercicios != null) {
                listaRutinas.add(new Rutina(nombreUsuario, objetivo, intensidad, ejercicios));
            }
        }
        return listaRutinas;
    }
}
