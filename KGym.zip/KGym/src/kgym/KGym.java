package kgym;



public class KGym {

    public static void main(String[] args) {

        LoginApp holaprofeloqueremos = new LoginApp();

    }

}
