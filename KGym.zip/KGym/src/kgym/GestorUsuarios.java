package kgym;

import java.io.*;
import java.util.*;

public class GestorUsuarios {

    private static final String ARCHIVO_USUARIOS = "usuarios.txt";

    public static void guardarUsuario(Usuario usuario) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO_USUARIOS, true))) {
            writer.write(usuario.toString());
            writer.newLine();
        }
    }

    // Buscar usuario por nombre y clave
    public static Usuario obtenerUsuario(String nombre, String clave) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_USUARIOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 6) {
                    String nom = partes[0];
                    String pass = partes[1];
                    String avatar = partes[2];
                    int anio = Integer.parseInt(partes[3]);
                    double peso = Double.parseDouble(partes[4]);
                    double estatura = Double.parseDouble(partes[5]);

                    if (nom.equals(nombre) && pass.equals(clave)) {
                        return new Usuario(nom, pass, avatar, anio, peso, estatura);
                    }
                }
            }
        }
        return null; 
    }
}
