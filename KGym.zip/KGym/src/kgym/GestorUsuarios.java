package kgym;

import java.io.*;

public class GestorUsuarios {
    private static final String ARCHIVO = "usuarios.txt";

    public static void guardarUsuario(Usuario usuario) throws IOException {
        // Primero, verificar si el usuario ya está registrado
        if (existeUsuario(usuario.getNombre())) {
            throw new IOException("El usuario ya está registrado.");
        }

        // Si el usuario no existe, entonces lo registramos
        BufferedWriter writer = new BufferedWriter(new FileWriter(ARCHIVO, true));
        writer.write(usuario.toString());
        writer.newLine();
        writer.close();
    }

    public static boolean existeUsuario(String nombre) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO));
        String linea;
        while ((linea = reader.readLine()) != null) {
            String[] partes = linea.split(",");
            if (partes.length == 3 && partes[0].equals(nombre)) {
                reader.close();
                return true; // Usuario ya existe
            }
        }
        reader.close();
        return false; // Usuario no existe
    }
    
    public static boolean validarCredenciales(String nombre, String clave) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO));
        String linea;
        while ((linea = reader.readLine()) != null) {
            String[] partes = linea.split(",");
            if (partes.length == 3 && partes[0].equals(nombre) && partes[1].equals(clave)) {
                reader.close();
                return true;
            }
        }
        reader.close();
        return false;
    }

    public static Usuario obtenerUsuario(String nombre, String clave) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO));
        String linea;
        while ((linea = reader.readLine()) != null) {
            String[] partes = linea.split(",");
            if (partes.length == 3 && partes[0].equals(nombre) && partes[1].equals(clave)) {
                reader.close();
                return new Usuario(partes[0], partes[1], partes[2]);
            }
        }
        reader.close();
        return null;
    }
}

