package kgym;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;
import java.util.List;
import java.util.Locale;

public class VentanaPerfil extends JFrame {

    private Usuario usuario;
    private JTextArea areaRutinas;
    private JPanel panelCalendario;
    private JLabel labelMesAnio;
    private Map<Integer, JButton> botonesDias = new HashMap<>(); // día del mes -> botón
    private Set<Integer> diasMarcados = new HashSet<>();
    private int mesActual;
    private int anioActual;

    public VentanaPerfil(Usuario usuario) {
        this.usuario = usuario;

        setTitle("Perfil de Usuario");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        LocalDate ahora = LocalDate.now();
        mesActual = ahora.getMonthValue();
        anioActual = ahora.getYear();

        // Panel Izquierdo: Foto, datos y botones
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setLayout(new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS));
        panelIzquierdo.setPreferredSize(new Dimension(250, 600));

        ImageIcon icono = new ImageIcon("imagenes/" + usuario.getAvatar());
        JLabel labelFoto = new JLabel(new ImageIcon(icono.getImage().getScaledInstance(180, 180, Image.SCALE_SMOOTH)));
        JLabel labelNombre = new JLabel(usuario.getNombre(), SwingConstants.CENTER);

        labelNombre.setFont(new Font("Arial", Font.BOLD, 16));
        labelNombre.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelEdad = new JLabel("Edad: " + calcularEdad(usuario.getAnioNacimiento()) + " años");
        JLabel labelIMC = new JLabel(String.format("IMC: %.2f", usuario.getIMC()));
        labelEdad.setAlignmentX(Component.CENTER_ALIGNMENT);
        labelIMC.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnCrearRutina = new JButton("Crear Rutina");
        btnCrearRutina.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCrearRutina.addActionListener(e -> {
            new VentanaCrearRutina(usuario).addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent evt) {
                    cargarRutinas();
                }
            });
        });

        JButton btnVerRutinas = new JButton("Ver Rutinas Guardadas");
        btnVerRutinas.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnVerRutinas.addActionListener(e -> new VentanaRutinas(usuario));

        panelIzquierdo.add(Box.createVerticalStrut(20));
        panelIzquierdo.add(labelFoto);
        panelIzquierdo.add(Box.createVerticalStrut(10));
        panelIzquierdo.add(labelNombre);
        panelIzquierdo.add(Box.createVerticalStrut(5));
        panelIzquierdo.add(labelEdad);
        panelIzquierdo.add(Box.createVerticalStrut(5));
        panelIzquierdo.add(labelIMC);
        panelIzquierdo.add(Box.createVerticalStrut(15));
        panelIzquierdo.add(btnCrearRutina);
        panelIzquierdo.add(Box.createVerticalStrut(10));
        panelIzquierdo.add(btnVerRutinas);

        add(panelIzquierdo, BorderLayout.WEST);

        // Panel Central con calendario y rutinas
        JPanel panelCentral = new JPanel(new BorderLayout());

        // Panel superior para navegación de meses
        JPanel panelNavegacion = new JPanel(new BorderLayout());

        JButton btnMesAnterior = new JButton("< Mes anterior");
        btnMesAnterior.addActionListener(e -> {
            retrocederMes();
        });

        JButton btnMesSiguiente = new JButton("Mes siguiente >");
        btnMesSiguiente.addActionListener(e -> {
            avanzarMes();
        });

        labelMesAnio = new JLabel("", SwingConstants.CENTER);
        labelMesAnio.setFont(new Font("Arial", Font.BOLD, 16));

        panelNavegacion.add(btnMesAnterior, BorderLayout.WEST);
        panelNavegacion.add(labelMesAnio, BorderLayout.CENTER);
        panelNavegacion.add(btnMesSiguiente, BorderLayout.EAST);

        panelCentral.add(panelNavegacion, BorderLayout.NORTH);

        panelCalendario = new JPanel(new GridLayout(0, 7));
        panelCentral.add(panelCalendario, BorderLayout.CENTER);

        areaRutinas = new JTextArea();
        areaRutinas.setEditable(false);
        JScrollPane scrollRutinas = new JScrollPane(areaRutinas);
        scrollRutinas.setBorder(BorderFactory.createTitledBorder("Rutinas guardadas"));
        scrollRutinas.setPreferredSize(new Dimension(600, 200));

        panelCentral.add(scrollRutinas, BorderLayout.SOUTH);

        add(panelCentral, BorderLayout.CENTER);

        construirCalendario();

        cargarRutinas();

        setVisible(true);
    }

    private int calcularEdad(int anioNacimiento) {
        return Year.now().getValue() - anioNacimiento;
    }

    private void construirCalendario() {
        panelCalendario.removeAll();
        botonesDias.clear();
        diasMarcados.clear();

        labelMesAnio.setText(Month.of(mesActual).getDisplayName(TextStyle.FULL, Locale.getDefault()) + " " + anioActual);

        // Cargar progreso del mes actual
        cargarProgreso();

        // Encabezados de días
        String[] diasSemana = {"Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"};
        for (String d : diasSemana) {
            JLabel lbl = new JLabel(d, SwingConstants.CENTER);
            lbl.setFont(new Font("Arial", Font.BOLD, 14));
            panelCalendario.add(lbl);
        }

        LocalDate primeroMes = LocalDate.of(anioActual, mesActual, 1);
        int diaSemanaInicio = primeroMes.getDayOfWeek().getValue() % 7; // Domingo=0

        int diasMes = primeroMes.lengthOfMonth();

        for (int i = 0; i < diaSemanaInicio; i++) {
            panelCalendario.add(new JLabel(""));
        }

        for (int dia = 1; dia <= diasMes; dia++) {
            JButton btnDia = new JButton(String.valueOf(dia));
            btnDia.setMargin(new Insets(2, 2, 2, 2));
            btnDia.setBackground(Color.LIGHT_GRAY);

            if (diasMarcados.contains(dia)) {
                btnDia.setBackground(Color.GREEN);
                btnDia.setText(dia + " ✓");
            }

            final int diaFinal = dia;
            btnDia.addActionListener(e -> {
                if (diasMarcados.contains(diaFinal)) {
                    diasMarcados.remove(diaFinal);
                    btnDia.setBackground(Color.LIGHT_GRAY);
                    btnDia.setText(String.valueOf(diaFinal));
                } else {
                    diasMarcados.add(diaFinal);
                    btnDia.setBackground(Color.GREEN);
                    btnDia.setText(diaFinal + " ✓");
                }
                guardarProgreso();
            });

            botonesDias.put(dia, btnDia);
            panelCalendario.add(btnDia);
        }

        panelCalendario.revalidate();
        panelCalendario.repaint();
    }

    private void guardarProgreso() {
        String nombreArchivo = getArchivoProgreso();
        try (PrintWriter pw = new PrintWriter(new FileWriter(nombreArchivo))) {
            for (Integer dia : diasMarcados) {
                pw.println(dia);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarProgreso() {
        diasMarcados.clear();
        String nombreArchivo = getArchivoProgreso();
        try {
            File file = new File(nombreArchivo);
            if (!file.exists()) {
                return;
            }

            List<String> lineas = Files.readAllLines(file.toPath());
            for (String linea : lineas) {
                try {
                    int dia = Integer.parseInt(linea.trim());
                    diasMarcados.add(dia);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getArchivoProgreso() {
        // Ejemplo: progreso_juan_202505.txt
        return "progreso_" + usuario.getNombre() + "_" + anioActual + String.format("%02d", mesActual) + ".txt";
    }

    private void avanzarMes() {
        if (mesActual == 12) {
            mesActual = 1;
            anioActual++;
        } else {
            mesActual++;
        }
        construirCalendario();
    }

    private void retrocederMes() {
        if (mesActual == 1) {
            mesActual = 12;
            anioActual--;
        } else {
            mesActual--;
        }
        construirCalendario();
    }

    private void cargarRutinas() {
        try {
            List<Rutina> rutinas = GestorRutinas.cargarRutinas();
            StringBuilder sb = new StringBuilder();
            for (Rutina r : rutinas) {
                if (r.getNombreUsuario().equals(usuario.getNombre())) {
                    sb.append("Objetivo: ").append(r.getObjetivo()).append("\n");
                    sb.append("Intensidad: ").append(r.getIntensidad()).append("\n");
                    sb.append("Ejercicios:\n");
                    for (Ejercicio e : r.getEjercicios()) {
                        sb.append(" - ").append(e.getNombre())
                                .append(" (").append(e.getMusculo())
                                .append("): ").append(e.getSeries())
                                .append(" series x ").append(e.getRepeticiones())
                                .append(" repeticiones\n");
                    }
                    sb.append("\n");
                }
            }
            areaRutinas.setText(sb.toString());
        } catch (Exception e) {
            areaRutinas.setText("Error cargando rutinas.");
            e.printStackTrace();
        }
    }

}
