package kgym;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class VentanaPerfil extends JFrame {

    private Usuario usuario;
    private JTextArea areaRutinas;
    private JPanel panelCalendario;
    private JLabel labelMesAnio;
    private Map<Integer, JButton> botonesDias = new HashMap<>();
    private Set<Integer> diasMarcados = new HashSet<>();
    private int mesActual;
    private int anioActual;
    private List<Rutina> rutinasUsuario;

    public VentanaPerfil(Usuario usuario) {
        this.usuario = usuario;

        setTitle("Perfil de Usuario");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        LocalDate ahora = LocalDate.now();
        mesActual = ahora.getMonthValue();
        anioActual = ahora.getYear();

        // Panel Izquierdo: Foto, datos y botones
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setLayout(new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS));
        panelIzquierdo.setPreferredSize(new Dimension(250, 600));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        ImageIcon icono = new ImageIcon("imagenes/" + usuario.getAvatar());
        Image imagenAjustada = icono.getImage().getScaledInstance(180, 180, Image.SCALE_SMOOTH);
        JLabel labelFoto = new JLabel(new ImageIcon(imagenAjustada));
        labelFoto.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelNombre = new JLabel("Nombre: " + usuario.getNombre(), SwingConstants.CENTER);
        labelNombre.setFont(new Font("Arial", Font.BOLD, 16));
        labelNombre.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelEdad = new JLabel("Edad: " + calcularEdad(usuario.getAnioNacimiento()) + " años",
                SwingConstants.CENTER);
        labelEdad.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel labelIMC = new JLabel(String.format("IMC: %.2f", usuario.getIMC()), SwingConstants.CENTER);
        labelIMC.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel panelInfoUsuario = new JPanel();
        panelInfoUsuario.setLayout(new GridLayout(3, 1));
        panelInfoUsuario.add(labelNombre);
        panelInfoUsuario.add(labelEdad);
        panelInfoUsuario.add(labelIMC);
        panelInfoUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnCrearRutina = new JButton("Crear Rutina");
        btnCrearRutina.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCrearRutina.addActionListener(e -> {
            new VentanaCrearRutina(usuario).addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent evt) {
                    cargarRutinas();
                    construirCalendario();
                }
            });
        });

        JButton btnVerRutinas = new JButton("Ver Rutinas Guardadas");
        btnVerRutinas.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnVerRutinas.addActionListener(e -> new VentanaRutinas(usuario));

        JButton btnEliminarRutinas = new JButton("Eliminar Rutinas"); // Nuevo botón
        btnEliminarRutinas.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnEliminarRutinas.addActionListener(e -> eliminarRutinas()); // Acción para eliminar

        panelIzquierdo.add(Box.createVerticalStrut(20));
        panelIzquierdo.add(labelFoto);
        panelIzquierdo.add(Box.createVerticalStrut(10));
        panelIzquierdo.add(panelInfoUsuario);
        panelIzquierdo.add(Box.createVerticalStrut(15));
        panelIzquierdo.add(btnCrearRutina);
        panelIzquierdo.add(Box.createVerticalStrut(10));
        panelIzquierdo.add(btnVerRutinas);
        panelIzquierdo.add(Box.createVerticalStrut(10));
        panelIzquierdo.add(btnEliminarRutinas); // Agregar el botón

        add(panelIzquierdo, BorderLayout.WEST);

        // Panel Central
        JPanel panelCentral = new JPanel(new BorderLayout());

        // Panel de navegación de meses
        JPanel panelNavegacion = new JPanel(new BorderLayout());

        JButton btnMesAnterior = new JButton("< Mes anterior");
        btnMesAnterior.addActionListener(e -> retrocederMes());

        JButton btnMesSiguiente = new JButton("Mes siguiente >");
        btnMesSiguiente.addActionListener(e -> avanzarMes());

        labelMesAnio = new JLabel("", SwingConstants.CENTER);
        labelMesAnio.setFont(new Font("Arial", Font.BOLD, 16));

        panelNavegacion.add(btnMesAnterior, BorderLayout.WEST);
        panelNavegacion.add(labelMesAnio, BorderLayout.CENTER);
        panelNavegacion.add(btnMesSiguiente, BorderLayout.EAST);

        panelCentral.add(panelNavegacion, BorderLayout.NORTH);

        panelCalendario = new JPanel(new GridLayout(0, 7));
        panelCentral.add(panelCalendario, BorderLayout.CENTER);

        areaRutinas = new JTextArea();
        areaRutinas.setEditable(false);
        JScrollPane scrollRutinas = new JScrollPane(areaRutinas);
        scrollRutinas.setBorder(BorderFactory.createTitledBorder("Rutinas del día"));
        scrollRutinas.setPreferredSize(new Dimension(600, 200));

        panelCentral.add(scrollRutinas, BorderLayout.SOUTH);

        add(panelCentral, BorderLayout.CENTER);

        cargarRutinas();
        construirCalendario();

        setVisible(true);
    }

    private int calcularEdad(int anioNacimiento) {
        return Year.now().getValue() - anioNacimiento;
    }

    private void construirCalendario() {
        panelCalendario.removeAll();
        botonesDias.clear();

        labelMesAnio.setText(Month.of(mesActual).getDisplayName(TextStyle.FULL, Locale.getDefault()) + " " + anioActual);

        String[] diasSemana = {"Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"};
        for (String d : diasSemana) {
            JLabel lbl = new JLabel(d, SwingConstants.CENTER);
            lbl.setFont(new Font("Arial", Font.BOLD, 14));
            panelCalendario.add(lbl);
        }

        LocalDate primeroMes = LocalDate.of(anioActual, mesActual, 1);
        int diaSemanaInicio = primeroMes.getDayOfWeek().getValue() % 7;

        int diasMes = primeroMes.lengthOfMonth();

        for (int i = 0; i < diaSemanaInicio; i++) {
            panelCalendario.add(new JLabel(""));
        }

        for (int dia = 1; dia <= diasMes; dia++) {
            JButton btnDia = new JButton(String.valueOf(dia));
            btnDia.setMargin(new Insets(2, 2, 2, 2));
            btnDia.setBackground(Color.LIGHT_GRAY);

            final int diaFinal = dia;

            btnDia.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    mostrarRutinaDelDia(diaFinal);
                    btnDia.setBackground(Color.YELLOW);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    if (!diasMarcados.contains(diaFinal)) {
                        btnDia.setBackground(Color.LIGHT_GRAY);
                    }
                }
            });

            btnDia.addActionListener(e -> {
                if (diasMarcados.contains(diaFinal)) {
                    diasMarcados.remove(diaFinal);
                    btnDia.setBackground(Color.LIGHT_GRAY);
                    btnDia.setText(String.valueOf(diaFinal));
                } else {
                    diasMarcados.add(diaFinal);
                    btnDia.setBackground(Color.GREEN);
                    btnDia.setText(diaFinal + " ✓");
                }
                guardarProgreso();
            });

            if (diasMarcados.contains(dia)) {
                btnDia.setBackground(Color.GREEN);
                btnDia.setText(dia + " ✓");
            }

            botonesDias.put(dia, btnDia);
            panelCalendario.add(btnDia);
        }

        panelCalendario.revalidate();
        panelCalendario.repaint();
    }

    private void guardarProgreso() {
        String nombreArchivo = getArchivoProgreso();
        try (PrintWriter pw = new PrintWriter(new FileWriter(nombreArchivo))) {
            for (Integer dia : diasMarcados) {
                pw.println(dia);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarProgreso() {
        diasMarcados.clear();
        String nombreArchivo = getArchivoProgreso();
        try {
            File file = new File(nombreArchivo);
            if (!file.exists()) {
                return;
            }

            List<String> lineas = Files.readAllLines(file.toPath());
            for (String linea : lineas) {
                try {
                    int dia = Integer.parseInt(linea.trim());
                    diasMarcados.add(dia);
                } catch (NumberFormatException ignored) {
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getArchivoProgreso() {
        return "progreso_" + usuario.getNombre() + "_" + anioActual + String.format("%02d", mesActual)
                + ".txt";
    }

    private void avanzarMes() {
        if (mesActual == 12) {
            mesActual = 1;
            anioActual++;
        } else {
            mesActual++;
        }
        construirCalendario();
    }

    private void retrocederMes() {
        if (mesActual == 1) {
            mesActual = 12;
            anioActual--;
        } else {
            mesActual--;
        }
        construirCalendario();
    }

    private void mostrarRutinaDelDia(int dia) {
        LocalDate fechaSeleccionada = LocalDate.of(anioActual, mesActual, dia);
        String nombreDiaSemana = fechaSeleccionada.getDayOfWeek().getDisplayName(TextStyle.FULL,
                new Locale("es", "ES"));

        StringBuilder sb = new StringBuilder("Rutinas para el " + dia + " de "
                + fechaSeleccionada.getMonth().getDisplayName(TextStyle.FULL, new Locale("es", "ES"))
                + " de " + anioActual + " (" + nombreDiaSemana + "):\n\n");

        boolean rutinaEncontrada = false;
        for (Rutina rutina : rutinasUsuario) {
            for (String diaRutina : rutina.getDiasDeLaSemana()) {
                if (diaRutina.equalsIgnoreCase(nombreDiaSemana)) {
                    sb.append("Objetivo: ").append(rutina.getObjetivo()).append("\n");
                    sb.append("Intensidad: ").append(rutina.getIntensidad()).append("\n");
                    sb.append("Ejercicios:\n");
                    for (Ejercicio ejercicio : rutina.getEjercicios()) {
                        sb.append(" - ").append(ejercicio.getNombre())
                                .append(" (").append(ejercicio.getMusculo())
                                .append("): ").append(ejercicio.getSeries())
                                .append(" series x ").append(ejercicio.getRepeticiones()).append("\n");
                    }
                    sb.append("\n");
                    rutinaEncontrada = true;
                }
            }
        }

        if (!rutinaEncontrada) {
            sb.append("No hay rutinas programadas para este día.\n");
        }

        areaRutinas.setText(sb.toString());
    }

    private void cargarRutinas() {
        try {
            List<Rutina> rutinas = GestorRutinas.cargarRutinas();
            rutinasUsuario = rutinas.stream()
                    .filter(r -> r.getNombreUsuario().equals(usuario.getNombre()))
                    .collect(Collectors.toList());
        } catch (IOException e) {
            areaRutinas.setText("Error al cargar las rutinas.");
            e.printStackTrace();
        }
    }

    private void eliminarRutinas() {
        int opcion = JOptionPane.showConfirmDialog(this,
                "¿Seguro que quieres eliminar TODAS tus rutinas?",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            try {
                // Sobrescribir el archivo con contenido vacío (elimina todo)
                PrintWriter writer = new PrintWriter(new FileWriter("rutinas.txt"));
                writer.print("");
                writer.close();

                areaRutinas.setText("Todas las rutinas han sido eliminadas.");
                rutinasUsuario.clear(); // Limpiar la lista en memoria
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al eliminar las rutinas.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

}
