package kgym;

import javax.swing.*;
import java.awt.*;

public class VentanaPerfil extends JFrame {

    public VentanaPerfil(Usuario usuario) {
        setTitle("Perfil de Usuario");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel Izquierdo: Foto de perfil y nombre
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setLayout(new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS));
        panelIzquierdo.setPreferredSize(new Dimension(200, 400));

        // Cargar el avatar del usuario
        ImageIcon icono = new ImageIcon("imagenes/" + usuario.getAvatar()); 
        JLabel labelFoto = new JLabel(new ImageIcon(icono.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));
        JLabel labelNombre = new JLabel(usuario.getNombre(), SwingConstants.CENTER);
        labelNombre.setFont(new Font("Arial", Font.BOLD, 16));
        labelNombre.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelIzquierdo.add(Box.createVerticalStrut(20));
        panelIzquierdo.add(labelFoto);
        panelIzquierdo.add(Box.createVerticalStrut(10));
        panelIzquierdo.add(labelNombre);

        // Panel Central: Rutinas
        JPanel panelRutinas = new JPanel(new BorderLayout());
        panelRutinas.setBorder(BorderFactory.createTitledBorder("Rutinas"));

        // Panel Inferior: Progreso
        JPanel panelProgreso = new JPanel();
        panelProgreso.setBorder(BorderFactory.createTitledBorder("Progreso"));
        panelProgreso.add(new JLabel("Aquí se mostrará el progreso en forma de calendario o texto o una barra"));

        // Agregar paneles a la ventana
        add(panelIzquierdo, BorderLayout.WEST);
        add(panelRutinas, BorderLayout.CENTER);
        add(panelProgreso, BorderLayout.SOUTH);

        // Crear y agregar el botón "Salir"
        JButton botonSalir = new JButton("Salir");
        botonSalir.setPreferredSize(new Dimension(100, 40)); // Ajustar tamaño
        botonSalir.addActionListener(e -> System.exit(0)); // Cerrar la aplicación cuando se haga clic
        add(botonSalir, BorderLayout.NORTH);

        setVisible(true);
    }
}

